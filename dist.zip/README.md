# discan
A simple NPM Module, for easily create Discord Bots with TypeScript.

# Version 0.1.0
The start of the package.

# Version 0.1.1
Some updates in NPM and in the repository.

# Version 0.1.2
Now in every command is beeing injected, all commands names.