export interface CanAdd {
    ref: any,
    name: string
}