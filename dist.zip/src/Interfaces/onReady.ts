export interface OnReady {
    diOnReady();
}