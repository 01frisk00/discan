export function DiCommand() {
    return (constructor: Function) => { }
}