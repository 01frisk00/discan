export function DiService() {
    return (constructor: Function) => { }
}